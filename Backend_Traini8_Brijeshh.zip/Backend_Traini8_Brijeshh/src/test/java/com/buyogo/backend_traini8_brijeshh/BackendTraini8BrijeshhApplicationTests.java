package com.buyogo.backend_traini8_brijeshh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendTraini8BrijeshhApplicationTests {

    @Test
    void contextLoads() {
    }

}
