package com.buyogo.backend_traini8_brijeshh.model;

import jakarta.persistence.Embeddable;
import lombok.*;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
class Address {
    private String detailedAddress;
    private String city;
    private String state;
    private String pincode;
}
