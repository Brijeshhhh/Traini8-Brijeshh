package com.buyogo.backend_traini8_brijeshh.repository;

import com.buyogo.backend_traini8_brijeshh.model.TrainingCenter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TrainingCenterRepository extends JpaRepository<TrainingCenter, Long> {}
