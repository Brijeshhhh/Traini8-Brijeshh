package com.buyogo.backend_traini8_brijeshh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTraini8BrijeshhApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendTraini8BrijeshhApplication.class, args);
    }

}
